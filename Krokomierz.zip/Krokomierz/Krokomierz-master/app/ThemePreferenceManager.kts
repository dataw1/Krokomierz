
package com.example.projekt

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map


val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "theme_settings")

class ThemePreferenceManager(private val context: Context) {

    companion object {

        val DARK_THEME_KEY = booleanPreferencesKey("dark_theme_key")
    }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[DARK_THEME_KEY] ?: false
        }

    // Funkcja zapisująca wybór motywu
    suspend fun setDarkTheme(isDark: Boolean) {
        context.dataStore.edit { settings ->
            settings[DARK_THEME_KEY] = isDark
        }
    }
}